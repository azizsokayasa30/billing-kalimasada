/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.6.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: radius
-- ------------------------------------------------------
-- Server version	10.6.22-MariaDB-0ubuntu0.22.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bandwidth_profile`
--

DROP TABLE IF EXISTS `bandwidth_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `bandwidth_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bandwidth_name` varchar(100) NOT NULL,
  `upload_min` decimal(10,2) DEFAULT 0.00 COMMENT 'Upload minimum dalam Mbps',
  `upload_max` decimal(10,2) DEFAULT 0.00 COMMENT 'Upload maksimum dalam Mbps',
  `download_min` decimal(10,2) DEFAULT 0.00 COMMENT 'Download minimum dalam Mbps',
  `download_max` decimal(10,2) DEFAULT 0.00 COMMENT 'Download maksimum dalam Mbps',
  `max_limit` varchar(50) DEFAULT NULL COMMENT 'Max Limit format: 5M/5M',
  `limit_at` varchar(50) DEFAULT NULL COMMENT 'Limit at format: 5M/5M',
  `burst_threshold` varchar(100) DEFAULT NULL COMMENT 'Burst - Threshold - Time - Priority format: 8M/8M 4M/4M 32/32 8',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `bandwidth_name` (`bandwidth_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bandwidth_profile`
--

LOCK TABLES `bandwidth_profile` WRITE;
/*!40000 ALTER TABLE `bandwidth_profile` DISABLE KEYS */;
INSERT INTO `bandwidth_profile` VALUES (1,'GOLD',5.00,5.00,5.00,5.00,NULL,NULL,NULL,'2025-12-06 11:07:22','2025-12-06 11:07:22');
/*!40000 ALTER TABLE `bandwidth_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotspot_profile`
--

DROP TABLE IF EXISTS `hotspot_profile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotspot_profile` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `plan_name` varchar(100) NOT NULL,
  `bandwidth_id` int(11) DEFAULT NULL COMMENT 'ID dari bandwidth_profile',
  `capital_price` decimal(15,2) DEFAULT 0.00 COMMENT 'Harga modal',
  `sell_price` decimal(15,2) DEFAULT 0.00 COMMENT 'Harga jual',
  `duration_value` int(11) DEFAULT NULL COMMENT 'Nilai durasi (NULL = unlimited)',
  `duration_unit` enum('MINUTES','HOURS','DAYS','MONTHS') DEFAULT 'DAYS' COMMENT 'Unit durasi',
  `duration_days` int(11) DEFAULT NULL COMMENT 'Durasi dalam hari (NULL = unlimited)',
  `quota_bytes` bigint(20) DEFAULT NULL COMMENT 'Quota dalam bytes (NULL = unlimited)',
  `plan_validity_value` int(11) DEFAULT NULL COMMENT 'Nilai validitas plan (NULL = unlimited, 0 = unlimited)',
  `plan_validity_unit` enum('MINUTES','HOURS','DAYS','MONTHS') DEFAULT 'DAYS' COMMENT 'Unit validitas plan',
  `plan_validity_days` int(11) DEFAULT NULL COMMENT 'Validitas plan dalam hari (NULL = unlimited)',
  `shared_users` int(11) DEFAULT 1 COMMENT 'Jumlah user yang bisa share (1 = single device)',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `plan_name` (`plan_name`),
  KEY `bandwidth_id` (`bandwidth_id`),
  CONSTRAINT `fk_hotspot_bandwidth` FOREIGN KEY (`bandwidth_id`) REFERENCES `bandwidth_profile` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotspot_profile`
--

LOCK TABLES `hotspot_profile` WRITE;
/*!40000 ALTER TABLE `hotspot_profile` DISABLE KEYS */;
INSERT INTO `hotspot_profile` VALUES (1,'PAKET-5000',1,5000.00,5000.00,2,'MINUTES',NULL,NULL,10,'MINUTES',NULL,1,'2025-12-06 11:18:45','2025-12-06 11:18:45');
/*!40000 ALTER TABLE `hotspot_profile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotspot_profiles`
--

DROP TABLE IF EXISTS `hotspot_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotspot_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(128) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `comment` text DEFAULT NULL,
  `rate_limit_value` varchar(32) DEFAULT NULL,
  `rate_limit_unit` varchar(10) DEFAULT NULL,
  `burst_limit_value` varchar(32) DEFAULT NULL,
  `burst_limit_unit` varchar(10) DEFAULT NULL,
  `session_timeout_value` int(11) DEFAULT NULL,
  `session_timeout_unit` varchar(10) DEFAULT NULL,
  `idle_timeout_value` int(11) DEFAULT NULL,
  `idle_timeout_unit` varchar(10) DEFAULT NULL,
  `limit_uptime_value` int(11) DEFAULT NULL,
  `limit_uptime_unit` varchar(10) DEFAULT NULL,
  `validity_value` int(11) DEFAULT NULL,
  `validity_unit` varchar(10) DEFAULT NULL,
  `shared_users` int(11) DEFAULT 1,
  `local_address` varchar(64) DEFAULT NULL,
  `remote_address` varchar(64) DEFAULT NULL,
  `dns_server` varchar(255) DEFAULT NULL,
  `parent_queue` varchar(64) DEFAULT NULL,
  `address_list` varchar(64) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupname` (`groupname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotspot_profiles`
--

LOCK TABLES `hotspot_profiles` WRITE;
/*!40000 ALTER TABLE `hotspot_profiles` DISABLE KEYS */;
INSERT INTO `hotspot_profiles` VALUES (1,'paket-20mbps','Paket-20Mbps',NULL,'20','M',NULL,'K',NULL,'s',NULL,'s',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2025-12-08 11:42:44','2025-12-08 11:42:44');
/*!40000 ALTER TABLE `hotspot_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mikrotik_nas`
--

DROP TABLE IF EXISTS `mikrotik_nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `mikrotik_nas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nas_name` varchar(100) NOT NULL,
  `nas_type` varchar(50) DEFAULT 'mikrotik',
  `api_url` varchar(255) DEFAULT NULL,
  `api_username` varchar(100) DEFAULT NULL,
  `api_password` varchar(255) DEFAULT NULL,
  `nas_ip` varchar(50) DEFAULT NULL,
  `api_port` int(11) DEFAULT 8728,
  `shared_secret` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') DEFAULT 'active',
  `deskripsi` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nas_name` (`nas_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mikrotik_nas`
--

LOCK TABLES `mikrotik_nas` WRITE;
/*!40000 ALTER TABLE `mikrotik_nas` DISABLE KEYS */;
INSERT INTO `mikrotik_nas` VALUES (1,'DIST','mikrotik','192.168.1.2','APISistem','220208','192.168.1.2',8005,'testing123','active','','2025-12-06 03:58:28','2025-12-06 04:31:40');
/*!40000 ALTER TABLE `mikrotik_nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `nas`
--

DROP TABLE IF EXISTS `nas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `nas` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `nasname` varchar(128) NOT NULL,
  `shortname` varchar(32) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'other',
  `ports` int(5) DEFAULT NULL,
  `secret` varchar(60) NOT NULL DEFAULT 'secret',
  `server` varchar(64) DEFAULT NULL,
  `community` varchar(50) DEFAULT NULL,
  `description` varchar(200) DEFAULT 'RADIUS Client',
  PRIMARY KEY (`id`),
  KEY `nasname` (`nasname`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nas`
--

LOCK TABLES `nas` WRITE;
/*!40000 ALTER TABLE `nas` DISABLE KEYS */;
/*!40000 ALTER TABLE `nas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pppoe_profiles`
--

DROP TABLE IF EXISTS `pppoe_profiles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pppoe_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `groupname` varchar(128) NOT NULL,
  `display_name` varchar(128) NOT NULL,
  `comment` text DEFAULT NULL,
  `rate_limit` varchar(128) DEFAULT NULL,
  `local_address` varchar(64) DEFAULT NULL,
  `remote_address` varchar(64) DEFAULT NULL,
  `dns_server` varchar(128) DEFAULT NULL,
  `parent_queue` varchar(128) DEFAULT NULL,
  `address_list` varchar(128) DEFAULT NULL,
  `bridge_learning` varchar(16) NOT NULL DEFAULT 'default',
  `use_mpls` varchar(16) NOT NULL DEFAULT 'default',
  `use_compression` varchar(16) NOT NULL DEFAULT 'default',
  `use_encryption` varchar(16) NOT NULL DEFAULT 'default',
  `only_one` varchar(16) NOT NULL DEFAULT 'default',
  `change_tcp_mss` varchar(16) NOT NULL DEFAULT 'default',
  `use_upnp` varchar(16) NOT NULL DEFAULT 'default',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `groupname` (`groupname`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pppoe_profiles`
--

LOCK TABLES `pppoe_profiles` WRITE;
/*!40000 ALTER TABLE `pppoe_profiles` DISABLE KEYS */;
INSERT INTO `pppoe_profiles` VALUES (1,'silver','Silver',NULL,'10M/10M',NULL,'POOL-PPPoE',NULL,NULL,NULL,'default','default','default','default','default','default','default','2025-11-28 06:26:26','2025-11-28 06:26:26');
/*!40000 ALTER TABLE `pppoe_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radacct`
--

DROP TABLE IF EXISTS `radacct`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radacct` (
  `radacctid` bigint(21) NOT NULL AUTO_INCREMENT,
  `acctsessionid` varchar(64) NOT NULL DEFAULT '',
  `acctuniqueid` varchar(32) NOT NULL DEFAULT '',
  `username` varchar(64) NOT NULL DEFAULT '',
  `realm` varchar(64) DEFAULT '',
  `nasipaddress` varchar(15) NOT NULL DEFAULT '',
  `nasportid` varchar(32) DEFAULT NULL,
  `nasporttype` varchar(32) DEFAULT NULL,
  `acctstarttime` datetime DEFAULT NULL,
  `acctupdatetime` datetime DEFAULT NULL,
  `acctstoptime` datetime DEFAULT NULL,
  `acctinterval` int(12) DEFAULT NULL,
  `acctsessiontime` int(12) unsigned DEFAULT NULL,
  `acctauthentic` varchar(32) DEFAULT NULL,
  `connectinfo_start` varchar(128) DEFAULT NULL,
  `connectinfo_stop` varchar(128) DEFAULT NULL,
  `acctinputoctets` bigint(20) DEFAULT NULL,
  `acctoutputoctets` bigint(20) DEFAULT NULL,
  `calledstationid` varchar(50) NOT NULL DEFAULT '',
  `callingstationid` varchar(50) NOT NULL DEFAULT '',
  `acctterminatecause` varchar(32) NOT NULL DEFAULT '',
  `servicetype` varchar(32) DEFAULT NULL,
  `framedprotocol` varchar(32) DEFAULT NULL,
  `framedipaddress` varchar(15) NOT NULL DEFAULT '',
  `framedipv6address` varchar(45) NOT NULL DEFAULT '',
  `framedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `framedinterfaceid` varchar(44) NOT NULL DEFAULT '',
  `delegatedipv6prefix` varchar(45) NOT NULL DEFAULT '',
  `class` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`radacctid`),
  UNIQUE KEY `acctuniqueid` (`acctuniqueid`),
  KEY `username` (`username`),
  KEY `framedipaddress` (`framedipaddress`),
  KEY `framedipv6address` (`framedipv6address`),
  KEY `framedipv6prefix` (`framedipv6prefix`),
  KEY `framedinterfaceid` (`framedinterfaceid`),
  KEY `delegatedipv6prefix` (`delegatedipv6prefix`),
  KEY `acctsessionid` (`acctsessionid`),
  KEY `acctsessiontime` (`acctsessiontime`),
  KEY `acctstarttime` (`acctstarttime`),
  KEY `acctinterval` (`acctinterval`),
  KEY `acctstoptime` (`acctstoptime`),
  KEY `nasipaddress` (`nasipaddress`),
  KEY `class` (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radacct`
--

LOCK TABLES `radacct` WRITE;
/*!40000 ALTER TABLE `radacct` DISABLE KEYS */;
/*!40000 ALTER TABLE `radacct` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radcheck`
--

DROP TABLE IF EXISTS `radcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=1014 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radcheck`
--

LOCK TABLES `radcheck` WRITE;
/*!40000 ALTER TABLE `radcheck` DISABLE KEYS */;
INSERT INTO `radcheck` VALUES (1,'demo','Cleartext-Password',':=','demo'),(1004,'5I3YMKE','Cleartext-Password',':=','5I3YMKE'),(1005,'56486M8','Cleartext-Password',':=','56486M8'),(1006,'1FSK6','Cleartext-Password',':=','1FSK6'),(1007,'1FSK6','Called-Station-Id','==','JALUR-SELATAN'),(1008,'1FSK6','Max-All-Session',':=','60'),(1009,'1FSK6','Expire-After',':=','120'),(1010,'1ETE0','Cleartext-Password',':=','1ETE0'),(1011,'1ETE0','Called-Station-Id','==','JALUR-SELATAN'),(1012,'1ETE0','Max-All-Session',':=','60'),(1013,'1ETE0','Expire-After',':=','120');
/*!40000 ALTER TABLE `radcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupcheck`
--

DROP TABLE IF EXISTS `radgroupcheck`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radgroupcheck` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '==',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupcheck`
--

LOCK TABLES `radgroupcheck` WRITE;
/*!40000 ALTER TABLE `radgroupcheck` DISABLE KEYS */;
INSERT INTO `radgroupcheck` VALUES (1,'silver','Simultaneous-Use',':=','1');
/*!40000 ALTER TABLE `radgroupcheck` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radgroupreply`
--

DROP TABLE IF EXISTS `radgroupreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radgroupreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `groupname` (`groupname`(32))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radgroupreply`
--

LOCK TABLES `radgroupreply` WRITE;
/*!40000 ALTER TABLE `radgroupreply` DISABLE KEYS */;
INSERT INTO `radgroupreply` VALUES (1,'silver','MikroTik-Rate-Limit',':=','10M/10M'),(2,'silver','Framed-Pool',':=','POOL-PPPoE'),(3,'paket-20mbps','MikroTik-Rate-Limit',':=','20M/20M');
/*!40000 ALTER TABLE `radgroupreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radpostauth`
--

DROP TABLE IF EXISTS `radpostauth`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radpostauth` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `pass` varchar(64) NOT NULL DEFAULT '',
  `reply` varchar(32) NOT NULL DEFAULT '',
  `authdate` timestamp(6) NOT NULL DEFAULT current_timestamp(6) ON UPDATE current_timestamp(6),
  `class` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `username` (`username`),
  KEY `class` (`class`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radpostauth`
--

LOCK TABLES `radpostauth` WRITE;
/*!40000 ALTER TABLE `radpostauth` DISABLE KEYS */;
INSERT INTO `radpostauth` VALUES (1,'demo','demo','Access-Accept','2025-11-28 06:31:41.028839',NULL);
/*!40000 ALTER TABLE `radpostauth` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radreply`
--

DROP TABLE IF EXISTS `radreply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radreply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `attribute` varchar(64) NOT NULL DEFAULT '',
  `op` char(2) NOT NULL DEFAULT '=',
  `value` varchar(253) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=1012 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radreply`
--

LOCK TABLES `radreply` WRITE;
/*!40000 ALTER TABLE `radreply` DISABLE KEYS */;
INSERT INTO `radreply` VALUES (1004,'5I3YMKE','Session-Timeout',':=','3600'),(1005,'56486M8','Session-Timeout',':=','3600'),(1006,'1FSK6','Reply-Message',':=','voucher'),(1007,'1FSK6','Mikrotik-Server',':=','JALUR-SELATAN'),(1008,'1FSK6','Session-Timeout',':=','60'),(1009,'1ETE0','Reply-Message',':=','voucher'),(1010,'1ETE0','Mikrotik-Server',':=','JALUR-SELATAN'),(1011,'1ETE0','Session-Timeout',':=','60');
/*!40000 ALTER TABLE `radreply` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `radusergroup`
--

DROP TABLE IF EXISTS `radusergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `radusergroup` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL DEFAULT '',
  `groupname` varchar(64) NOT NULL DEFAULT '',
  `priority` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `username` (`username`(32))
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `radusergroup`
--

LOCK TABLES `radusergroup` WRITE;
/*!40000 ALTER TABLE `radusergroup` DISABLE KEYS */;
INSERT INTO `radusergroup` VALUES (1,'demo','silver',1),(2,'1FSK6','Paket-20Mbps',1),(3,'1ETE0','Paket-20Mbps',1);
/*!40000 ALTER TABLE `radusergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `server_hotspot`
--

DROP TABLE IF EXISTS `server_hotspot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `server_hotspot` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_server` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `nama_server` (`nama_server`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `server_hotspot`
--

LOCK TABLES `server_hotspot` WRITE;
/*!40000 ALTER TABLE `server_hotspot` DISABLE KEYS */;
INSERT INTO `server_hotspot` VALUES (1,'JALUR-SELATAN','*7','2025-12-06 06:01:40','2025-12-06 06:01:40'),(2,'JALUR-UTARA','*8','2025-12-06 06:10:34','2025-12-06 06:10:34');
/*!40000 ALTER TABLE `server_hotspot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `setting_umum`
--

DROP TABLE IF EXISTS `setting_umum`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `setting_umum` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) DEFAULT NULL COMMENT 'Nama Perusahaan',
  `company_address` text DEFAULT NULL COMMENT 'Alamat Perusahaan',
  `company_phone` varchar(50) DEFAULT NULL COMMENT 'Telepon Perusahaan',
  `company_email` varchar(100) DEFAULT NULL COMMENT 'Email Perusahaan',
  `company_website` varchar(255) DEFAULT NULL COMMENT 'Website Perusahaan',
  `logo_path` varchar(255) DEFAULT NULL COMMENT 'Path logo perusahaan',
  `hotspot_domain` varchar(255) DEFAULT NULL COMMENT 'Domain/IP Hotspot',
  `currency` varchar(10) DEFAULT 'Rp' COMMENT 'Mata uang',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `setting_umum`
--

LOCK TABLES `setting_umum` WRITE;
/*!40000 ALTER TABLE `setting_umum` DISABLE KEYS */;
INSERT INTO `setting_umum` VALUES (1,'CVL Hotspot','','','','','assets/images/company/logo_1765093033_69352ea950cef.png','192.168.1.1','Rp','2025-12-07 06:52:03','2025-12-07 07:48:29');
/*!40000 ALTER TABLE `setting_umum` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `setting_key` varchar(100) NOT NULL,
  `setting_value` text DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `setting_key` (`setting_key`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'radius_radius_host','localhost','2025-12-06 03:08:42'),(2,'radius_radius_auth_port','1812','2025-12-06 03:08:42'),(3,'radius_radius_acct_port','1813','2025-12-06 03:08:42'),(4,'radius_radius_secret','testing123','2025-12-06 03:08:42'),(5,'radius_nas_ip','192.168.1.2','2025-12-06 03:08:42'),(6,'nas_nas_name','Mikrotik-Distribusi','2025-12-06 03:09:56'),(7,'nas_nas_type','mikrotik','2025-12-06 03:09:56'),(8,'nas_api_url','192.168.1.2:8005','2025-12-06 03:09:56'),(9,'nas_api_username','APISistem','2025-12-06 03:09:56'),(10,'nas_api_password','220208','2025-12-06 03:09:56'),(15,'radius_radius_db_name','radius','2025-12-06 04:01:11'),(16,'radius_radius_db_host','localhost','2025-12-06 04:01:11'),(17,'radius_radius_db_user','radius','2025-12-06 04:01:11'),(18,'radius_radius_db_pass','sLAIpsOQP5NZXiQKqZEz77eKn','2025-12-06 04:01:11');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_template`
--

DROP TABLE IF EXISTS `voucher_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voucher_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_name` varchar(100) NOT NULL,
  `accessible_by` enum('all_users','admin_only') DEFAULT 'all_users',
  `status` enum('enabled','disabled') DEFAULT 'enabled',
  `template_code` text NOT NULL COMMENT 'HTML/CSS template code',
  `created_at` datetime DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `template_name` (`template_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_template`
--

LOCK TABLES `voucher_template` WRITE;
/*!40000 ALTER TABLE `voucher_template` DISABLE KEYS */;
INSERT INTO `voucher_template` VALUES (2,'Template Default','all_users','enabled','\n<!-- ============================================ -->\n<!-- TEMPLATE VOUCHER - STRUKTUR YANG TIDAK BOLEH DIUBAH -->\n<!-- ============================================ -->\n<!-- \n    PENTING: Bagian-bagian berikut TIDAK BOLEH DIUBAH agar ukuran voucher tetap proporsional:\n    \n    1. ✅ BOLEH DIUBAH: \n       - Warna, font-size (dalam batas wajar), text-align, margin, padding\n       - Konten teks (label, format display)\n       - Background color, border color\n    \n    2. ❌ TIDAK BOLEH DIUBAH:\n       - Class name: .voucher, .voucher-header, .voucher-content, .voucher-code-field, dll\n       - Struktur HTML: div dengan class tersebut HARUS tetap ada\n       - Display properties: flex, grid, position (relative/absolute)\n       - Ukuran container: width, height, min-height, max-height\n       - Grid layout: grid-template-columns, grid-template-rows (jika ada)\n       - Position properties: top, right, bottom, left (untuk .voucher-number)\n    \n    3. ✅ VARIABEL YANG TERSEDIA:\n       - {$vs[\'code\']} = Username voucher\n       - {$vs[\'secret\']} = Password voucher\n       - {$vs[\'number\']} = Nomor urut voucher\n       - {$vs[\'duration\']} = Durasi (format: 2m, 12h, dll)\n       - {$vs[\'validity\']} = Masa aktif/Expired (format: 10m, 24h, dll atau \"Belum Digunakan\")\n       - {$vs[\'price\']} = Harga voucher (format: 5000)\n       - {$vs[\'currency_code\']} = Kode mata uang (default: Rp.)\n       - {$vs[\'company_name\']} = Nama perusahaan\n       - {$vs[\'logo_url\']} = URL logo perusahaan\n       - {$vs[\'hotspot_domain\']} = Domain/IP hotspot (contoh: 192.168.1.1)\n    \n    4. ✅ KONDISI YANG TERSEDIA:\n       - {if $vs[\'code\'] eq $vs[\'secret\']} ... {/if} = Jika username == password\n       - {if $vs[\'code\'] neq $vs[\'secret\']} ... {/if} = Jika username != password\n-->\n\n<!-- START CUSTOM HTML - BOLEH DIUBAH DI SINI -->\n<style type=\"text/css\">\n/* ============================================ */\n/* STYLING VOUCHER - BOLEH DIUBAH (dalam batas wajar) */\n/* ============================================ */\n\n/* Container voucher - TIDAK BOLEH DIUBAH ukuran dan struktur */\n.voucher {\n    border: 1px solid #dee2e6;\n    border-radius: 2px;\n    padding: 3px;\n    display: flex;\n    flex-direction: column;\n    background: white;\n    page-break-inside: avoid;\n    overflow: visible;\n    min-height: 0;\n    position: relative;\n}\n\n/* Header dengan logo dan brand - BOLEH DIUBAH warna, font-size */\n.voucher-header {\n    display: flex;\n    align-items: center;\n    margin-bottom: 1px;\n    padding-bottom: 1px;\n    border-bottom: 1px solid #dee2e6;\n}\n\n.voucher-logo {\n    width: 24px;\n    height: 24px;\n    object-fit: contain;\n    margin-right: 4px;\n    border-radius: 50%;\n}\n\n.voucher-brand {\n    font-size: 14px;\n    font-weight: bold;\n    color: #333;\n    flex: 1;\n    text-align: left;\n}\n\n/* Separator - BOLEH DIUBAH warna */\n.voucher-separator {\n    height: 1px;\n    background: #dee2e6;\n    margin: 1px 0;\n}\n\n/* Label Kode Voucher - BOLEH DIUBAH font-size, warna */\n.voucher-label {\n    text-align: center;\n    font-size: 12px;\n    color: #666;\n    margin: 1px 0;\n    font-weight: 500;\n}\n\n/* Field Kode Voucher - BOLEH DIUBAH font-size, warna, padding */\n.voucher-code-field {\n    border: 1px solid #dee2e6;\n    border-radius: 2px;\n    padding: 3px 4px;\n    text-align: center;\n    background: #f8f9fa;\n    margin: 1px 0;\n    font-family: \'Courier New\', monospace;\n    font-weight: bold;\n    font-size: 13px;\n    color: #333;\n    min-height: 18px;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n}\n\n/* Content area - BOLEH DIUBAH font-size, warna, spacing */\n.voucher-content {\n    flex: 1;\n    display: flex;\n    flex-direction: column;\n    justify-content: flex-start;\n    font-size: 8px;\n    line-height: 1;\n    padding: 1px 0 2px 0;\n    min-height: 0;\n    overflow: visible;\n}\n\n/* Field row untuk durasi, expired, harga - BOLEH DIUBAH */\n.voucher-field-row {\n    display: flex;\n    justify-content: space-between;\n    margin: 2px 0;\n    font-size: 8px;\n    font-weight: bold;\n    line-height: 1.2;\n    align-items: center;\n}\n\n/* Nomor urut voucher - TIDAK BOLEH DIUBAH position dan size */\n.voucher-number {\n    position: absolute;\n    top: 2px;\n    right: 2px;\n    font-size: 12px;\n    font-weight: bold;\n    color: #333;\n    background: #f8f9fa;\n    border-radius: 50%;\n    width: 18px;\n    height: 18px;\n    display: flex;\n    align-items: center;\n    justify-content: center;\n    border: 1px solid #dee2e6;\n}\n</style>\n\n<!-- Nomor Urut Voucher - TIDAK BOLEH DIUBAH -->\n<div class=\"voucher-number\">{$vs[\'number\']}</div>\n\n<!-- Header dengan Logo dan Brand - BOLEH DIUBAH konten teks -->\n<div class=\"voucher-header\">\n    <img src=\"{$vs[\'logo_url\']}\" alt=\"Logo\" class=\"voucher-logo\" onerror=\"this.style.display=\'none\'; this.nextElementSibling.style.marginLeft=\'0\';\">\n    <div class=\"voucher-brand\">{$vs[\'company_name\']}</div>\n</div>\n\n<!-- Separator -->\n<div class=\"voucher-separator\"></div>\n\n<!-- Label Kode Voucher - BOLEH DIUBAH teks -->\n<div class=\"voucher-label\">Kode Voucher</div>\n\n<!-- Field Kode Voucher - BOLEH DIUBAH styling -->\n{if $vs[\'code\'] eq $vs[\'secret\']}\n    <!-- Jika username == password, tampilkan hanya code -->\n    <div class=\"voucher-code-field\">{$vs[\'code\']}</div>\n{else}\n    <!-- Jika username != password, tampilkan code dan secret -->\n    <div class=\"voucher-code-field\">{$vs[\'code\']} / {$vs[\'secret\']}</div>\n{/if}\n\n<!-- Separator -->\n<div class=\"voucher-separator\"></div>\n\n<!-- Content Area - BOLEH DIUBAH konten dan format -->\n<div class=\"voucher-content\">\n    <!-- Durasi, Expired dan Harga dalam satu baris - BOLEH DIUBAH format -->\n    <div class=\"voucher-field-row\">\n        <span style=\"color: #333;\">\n            Durasi: {$vs[\'duration\']} Expired: {$vs[\'validity\']}\n        </span>\n        <span style=\"color: #333; font-size: 9px;\">\n            {$vs[\'currency_code\']}{$vs[\'price\']}\n        </span>\n    </div>\n    \n    <!-- IP Login di tengah - BOLEH DIUBAH format -->\n    <div style=\"margin: 2px 0 3px 0; text-align: center; font-size: 7px; color: #333; line-height: 1.3; font-weight: 500;\">\n        Login: http://{$vs[\'hotspot_domain\']}\n    </div>\n</div>\n\n<!-- END CUSTOM HTML -->\n','2025-12-07 07:57:10','2025-12-07 08:54:11'),(3,'Template QR Default','all_users','enabled','\n<!-- ============================================ -->\n<!-- TEMPLATE QR DEFAULT - STRUKTUR MIKHMON -->\n<!-- ============================================ -->\n<!-- \n    PENTING: Template ini menggunakan struktur dari Mikhmon dengan QR Code\n    Template ini hanya berisi bagian ROW (table voucher), tanpa header/footer HTML\n    \n    VARIABEL YANG TERSEDIA:\n    - {$vs[\'code\']} = Username voucher\n    - {$vs[\'secret\']} = Password voucher\n    - {$vs[\'number\']} = Nomor urut voucher\n    - {$vs[\'duration\']} = Durasi (format: 2m, 12h, dll)\n    - {$vs[\'validity\']} = Masa aktif/Expired (format: 10m, 24h, dll)\n    - {$vs[\'price\']} = Harga voucher (format: 5000)\n    - {$vs[\'currency_code\']} = Kode mata uang (default: Rp.)\n    - {$vs[\'company_name\']} = Nama perusahaan/hotspot\n    - {$vs[\'logo_url\']} = URL logo perusahaan\n    - {$vs[\'hotspot_domain\']} = Domain/IP hotspot (contoh: 192.168.1.1)\n    - {$vs[\'timelimit\']} = Time limit (legacy)\n    - {$vs[\'datalimit\']} = Data limit (legacy)\n    - {$vs[\'validperiod\']} = Valid period (legacy)\n-->\n\n<style>\n    /* Styling untuk template QR Default - Kotak merah seperti referensi */\n    table.voucher {\n        display: inline-block;\n        border: 2px solid #FF0000;\n        margin: 2px;\n        border-collapse: collapse;\n        width: 230px;\n        table-layout: fixed;\n        background: #FFFFFF;\n        box-sizing: border-box;\n        position: relative;\n    }\n    table.voucher td {\n        padding: 5px;\n        vertical-align: middle;\n        box-sizing: border-box;\n    }\n    /* Border internal untuk pemisah */\n    table.voucher tr:not(:last-child) td {\n        border-bottom: 1px solid #FF0000;\n    }\n    @media print {\n        table { page-break-after:auto }\n        tr    { page-break-inside:avoid; page-break-after:auto }\n        td    { page-break-inside:avoid; page-break-after:auto }\n    }\n    /* Nomor urut di pojok kanan atas (panah merah) */\n    .voucher-number {\n        position: absolute;\n        top: 3px;\n        right: 3px;\n        font-size: 10px;\n        font-weight: bold;\n        color: #000000;\n        z-index: 10;\n        background: #FFFFFF;\n        padding: 2px 4px;\n    }\n    /* Kolom harga di kiri - vertical line merah (panah hijau) */\n    .price-col {\n        width: 20px;\n        min-width: 20px;\n        max-width: 20px;\n        padding: 0 3px 0 0;\n        border-right: 2px solid #FF0000;\n        position: relative;\n        vertical-align: middle;\n        box-sizing: border-box;\n        height: 100%;\n        overflow: hidden;\n    }\n    .price-col > div {\n        position: absolute;\n        left: 20%;\n        top: 50%;\n        transform: translate(-50%, -50%) rotate(-90deg);\n        white-space: nowrap;\n        font-weight: bold;\n        font-size: 10px;\n        color: #000000;\n        width: 35px;\n        text-align: center;\n        line-height: 1.2;\n        padding: 0;\n        margin: 0;\n        margin-left: -5px;\n    }\n    .price-col .price {\n        font-weight: bold;\n        font-size: 10px;\n        color: #000000;\n    }\n    /* Kolom QR Code di kanan bawah (panah hitam) */\n    .qrcode-col {\n        width: 65px;\n        min-width: 65px;\n        max-width: 65px;\n        text-align: center;\n        vertical-align: bottom;\n        padding: 5px;\n        box-sizing: border-box;\n    }\n    .qrcode {\n        height: 60px;\n        width: 60px;\n        display: inline-block;\n    }\n    /* Kolom konten di tengah */\n    .content-col {\n        padding: 5px 8px;\n        box-sizing: border-box;\n    }\n</style>\n\n<!-- Template tanpa foreach karena voucher-print.php sudah melakukan loop -->\n<!-- Struktur: Kotak merah, harga di kiri (panah hijau), nomor di kanan atas (panah merah), QR di kanan bawah (panah hitam) -->\n<div style=\"position: relative; display: inline-block;\">\n    <!-- Nomor urut di pojok kanan atas (panah merah) -->\n    <div class=\"voucher-number\">[{$vs[\'number\']}]</div>\n    <table class=\"voucher\">\n        <tbody>\n        <!-- Baris 1: Nama Hotspot -->\n        <tr>\n            <!-- Kolom 1: Harga (rotated) di kiri - vertical line merah (panah hijau) - rowspan 4 -->\n            <td class=\"price-col\" rowspan=\"4\">\n                <div>\n                    <span class=\"price\">{$vs[\'currency_code\']}{$vs[\'price\']}</span>\n                </div>\n            </td>\n            <!-- Kolom 2: Nama Hotspot -->\n            <td class=\"content-col\" colspan=\"2\" style=\"font-weight: bold; font-size: 14px;\">\n                {$vs[\'company_name\']}\n            </td>\n            <!-- Kolom 3: QR Code di kanan bawah (panah hitam) - rowspan 3 -->\n            <td class=\"qrcode-col\" rowspan=\"3\" style=\"vertical-align: bottom;\">\n                <div class=\"qrcode\" \n                     id=\"qrcode-{$vs[\'number\']}\" \n                     data-domain=\"{$vs[\'hotspot_domain\']}\" \n                     data-username=\"{$vs[\'code\']}\" \n                     data-password=\"{$vs[\'secret\']}\">\n                </div>\n            </td>  \n        </tr>\n        <!-- Baris 2: Kode Voucher - HANYA TAMPILKAN SALAH SATU -->\n        <tr>\n            <!-- Conditional akan diproses oleh SmartyTemplateParser -->\n            {if $vs[\'code\'] eq $vs[\'secret\']}\n            <td class=\"content-col\" colspan=\"2\" style=\"font-weight: bold; font-size: 18px; text-align: center; padding: 12px 8px;\">\n                {$vs[\'code\']}\n            </td>\n            {/if}\n            {if $vs[\'code\'] neq $vs[\'secret\']}\n            <td class=\"content-col\" colspan=\"2\" style=\"font-weight: bold; font-size: 15px; text-align: left; padding: 10px 8px; line-height: 1.5;\">\n                User: {$vs[\'code\']}\n                <br>\n                Pass: {$vs[\'secret\']}\n            </td>\n            {/if}\n        </tr>\n        <!-- Baris 3: Validity, Duration, Data Limit -->\n        <tr>\n            <td class=\"content-col\" colspan=\"2\" style=\"font-size: 10px; padding: 5px 8px;\">\n                <span class=\"validity\">{$vs[\'validity\']}</span> \n                <span class=\"timelimit\">{$vs[\'duration\']}</span> \n                <span class=\"datalimit\">{$vs[\'datalimit\']}</span>\n            </td>\n        </tr>\n        <!-- Baris 4: Login URL -->\n        <tr>\n            <td class=\"content-col\" colspan=\"3\" style=\"font-size: 10px; padding: 5px 8px;\">\n                Login: http://{$vs[\'hotspot_domain\']}\n            </td>\n        </tr>\n        </tbody>\n    </table>\n</div>\n\n<script>\n(function() {\n    var qrId = \"qrcode-{$vs[\'number\']}\";\n    var qrContainer = document.getElementById(qrId);\n    if (qrContainer) {\n        var domain = qrContainer.getAttribute(\"data-domain\") || \"\";\n        var username = qrContainer.getAttribute(\"data-username\") || \"\";\n        var password = qrContainer.getAttribute(\"data-password\") || \"\";\n        \n        function generateQR() {\n            if (typeof QRCode !== \"undefined\") {\n                var loginUrl = \"http://\" + domain + \"/login?username=\" + encodeURIComponent(username) + \"&password=\" + encodeURIComponent(password);\n                new QRCode(qrContainer, {\n                    text: loginUrl,\n                    width: 60,\n                    height: 60\n                });\n            } else {\n                setTimeout(generateQR, 100);\n            }\n        }\n        generateQR();\n    }\n})();\n</script>\n\n<script>\n    // Format validity and timelimit\n    document.addEventListener(\"DOMContentLoaded\", function() {\n        // Format validity\n        var validityElements = document.querySelectorAll(\".validity\");\n        validityElements.forEach(function(el) {\n            var x = el.innerHTML;\n            if (x && x.substring(x.length - 1) == \"d\") {\n                el.innerHTML = x.replace(\"d\", \"Hari\");\n            } else if (x && x.substring(x.length - 1) == \"h\") {\n                el.innerHTML = x.replace(\"h\", \"Jam\");\n            } else if (x && x.substring(x.length - 1) == \"w\") {\n                el.innerHTML = x.replace(\"w\", \"Minggu\");\n            }\n        });\n        \n        // Format timelimit\n        var timelimitElements = document.querySelectorAll(\".timelimit\");\n        timelimitElements.forEach(function(el) {\n            var x = el.innerHTML;\n            if (x && x.substring(x.length - 1) == \"d\") {\n                el.innerHTML = x.replace(\"d\", \"Hari\");\n            } else if (x && x.substring(x.length - 1) == \"h\") {\n                el.innerHTML = x.replace(\"h\", \"Jam\");\n            } else if (x && x.substring(x.length - 1) == \"w\") {\n                el.innerHTML = x.replace(\"w\", \"Minggu\");\n            }\n        });\n        \n        // Color coding for price\n        var tcolor = {\n            1500 : \"red\",\n            2000 : \"blue\",	\n            3000 : \"#33D4FF\",\n        };\n        \n        var priceElements = document.querySelectorAll(\".price\");\n        priceElements.forEach(function(el) {\n            var priceValue = parseInt(el.innerHTML.replace(/[^0-9]/g, \"\"));\n            if (tcolor[priceValue]) {\n                el.style.color = tcolor[priceValue];\n            }\n        });\n    });\n</script>\n\n<!-- Load QR Code library -->\n<script src=\"https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js\"></script>\n','2025-12-07 08:13:40','2025-12-07 10:06:54');
/*!40000 ALTER TABLE `voucher_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voucher_usage`
--

DROP TABLE IF EXISTS `voucher_usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `voucher_usage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `voucher_id` int(11) NOT NULL,
  `username` varchar(64) NOT NULL,
  `session_start` datetime DEFAULT NULL,
  `session_end` datetime DEFAULT NULL,
  `bytes_in` bigint(20) DEFAULT 0,
  `bytes_out` bigint(20) DEFAULT 0,
  `duration` int(11) DEFAULT 0 COMMENT 'Durasi dalam detik',
  PRIMARY KEY (`id`),
  KEY `voucher_id` (`voucher_id`),
  KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voucher_usage`
--

LOCK TABLES `voucher_usage` WRITE;
/*!40000 ALTER TABLE `voucher_usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `voucher_usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vouchers`
--

DROP TABLE IF EXISTS `vouchers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `vouchers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL,
  `validity_days` int(11) DEFAULT NULL COMMENT 'Masa berlaku dalam hari',
  `validity_hours` int(11) DEFAULT NULL COMMENT 'Masa berlaku dalam jam',
  `uptime_limit` int(11) DEFAULT NULL COMMENT 'Batas waktu online dalam detik',
  `data_limit` bigint(20) DEFAULT NULL COMMENT 'Batas data dalam bytes (NULL = unlimited)',
  `max_all_session` int(11) DEFAULT NULL COMMENT 'Maksimal session concurrent',
  `status` enum('active','expired','used') DEFAULT 'active',
  `created_at` datetime DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  `first_used_at` datetime DEFAULT NULL COMMENT 'Waktu pertama kali voucher digunakan (login pertama kali)',
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_status` (`status`),
  KEY `idx_expires_at` (`expires_at`),
  KEY `idx_first_used_at` (`first_used_at`)
) ENGINE=InnoDB AUTO_INCREMENT=1005 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vouchers`
--

LOCK TABLES `vouchers` WRITE;
/*!40000 ALTER TABLE `vouchers` DISABLE KEYS */;
INSERT INTO `vouchers` VALUES (1003,'5I3YMKE','5I3YMKE',0,1,NULL,NULL,NULL,'active','2025-12-07 08:37:05',NULL,NULL,'Server ID: 2. Service Plan ID: 1. Seller Fee: 5000.'),(1004,'56486M8','56486M8',0,1,NULL,NULL,NULL,'active','2025-12-07 08:37:05',NULL,NULL,'Server ID: 2. Service Plan ID: 1. Seller Fee: 5000.');
/*!40000 ALTER TABLE `vouchers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-08 12:53:41
